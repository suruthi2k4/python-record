## PPML Experiments


**1. Fundamentals with** *Numpy, Pandas, Matplotlib*

**2. Mathematical Operations:** *Euclidean distance*, *Dot product*, *Linear equation*

**3. Activation Functions:** *Sigmoid function*, *Tanh function*

**4. Gradient Descent:** *gradient descent algorithm*

**5. Vehicle Performance Analysis (using Pandas):**

**6. Data Wrangling:**

**7. Linear Regression:**

**8. Logistic Regression:**

**9. Linear Regression with Keras:**

**10. Support Vector Regression (SVR):**
